wget http://repo.continuum.io/archive/Anaconda3-4.1.1-Linux-x86_64.sh
bash Anaconda3-4.1.1-Linux-x86_64.sh
which python

echo "******************************************************************************************"
echo "*                                   REBOOT SSH CONNECTION                                *"
echo "******************************************************************************************"


